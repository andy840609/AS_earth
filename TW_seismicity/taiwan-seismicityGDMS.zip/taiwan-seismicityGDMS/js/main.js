$(function () {
    var observ = document.getElementsByClassName("observablehq");
    observ[0].setAttribute("id", "title");
    observ[1].setAttribute("id", "playController");
    observ[2].setAttribute("id", "speedController");
    observ[3].setAttribute("id", "date");
    observ[4].setAttribute("id", "film");
    // observ[5].setAttribute("id", "legend");

    // $('#banner').append($('#title'));
    $("#animation").append($("#date"));
    $("#animation").append($("#film"));
    // $("#animation").append($("#legend"));


    // $(window).resize(function () {
    var width = $(window).width();
    // var height = $(window).height();

    // if (width > height)
    //     var screen = height;
    // else
    //     var screen = width;

    // window.alert("W:" + width + " H:" + height);
    // width = 100;
    if (width >= 1000 && $('.menu').length < 1) {
        var nav = document.createElement("nav");
        nav.classList.add("menu");
        $('.toggle-menu').after(nav);

        var ul = document.createElement("ul");
        ul.setAttribute("id", "tools");
        ul.classList.add("active");
        $('.menu').append(ul);


        var div = document.createElement("div");
        div.setAttribute("id", "icons");
        $('.menu').append(div);

        $('.menu').BootSideMenu({
            side: "left",
            pushBody: true,
            width: '50vmin',
            icons: {
                left: 'fa fa-angle-double-left fa-1x ',
                right: 'fa fa-angle-double-right fa-1x ',
                down: 'fa fa-angle-double-down fa-1x ',
            },
            theme: 'customtheme',
            closeOnClick: false,
            remember: false,
        });

        //==put title in side menu
        var li = document.createElement("li");
        li.setAttribute("id", "item0");
        li.classList.add("current-item");
        $("#tools").append(li);
        $('#item0').append($('#title'));
        // $('#title:first-child').html("AAA");
        //========================


    }
    else if (width <= 1000) {
        // if ($("#tools").length > 0)
        //     $("#tools").remove();
        var ul = document.createElement("ul");
        ul.setAttribute("id", "tools");
        ul.classList.add("active");
        $('.toggle-menu').append(ul);
        // $('.menu').append(ul);
        // if ($('.menu').length > 0) {
        //     $('.toggle-menu').append($('#playController'));
        //     $('.toggle-menu').append($('#speedController'));
        //     $('.menu').remove();
        // }
        $('#banner').append($('#title'));

        // #date.observablehq--date {

        //     position: absolute;
        //     top: 15vmin;
        //     font - size: 4vmin;
        //     z - index: 10;
        // }

        // $('#date').css({
        //     size: 100,
        //     position: absolute,
        //     top: "150vmin",
        // });
    }
    // });
    for (var i = 0; i < 2; i++) {
        var li = document.createElement("li");
        li.setAttribute("id", "item" + (i + 1));
        li.classList.add("current-item");
        $("#tools").append(li);
    }
    $('#item1').append($('#playController'));
    $('#item2').append($('#speedController'));



    for (var i = 0; i < 2; i++) {
        var img = document.createElement("img");
        img.setAttribute("id", "icon" + (i + 1));
        img.width = "90";
        // img.height = "100";
        $('#icons').append(img);
        // window.alert("AAA");
    }
    $('#icon1').attr("src", "./img/cwb.png");
    $('#icon2').attr("src", "./img/Logo.jpg");

    //=================for window width<=860
    $('.toggle-nav').click(function (e) {
        $(this).toggleClass('active');
        $('.toggle-menu ul').toggleClass('active');

        e.preventDefault();
    });








    //=================legend onScroll
    $('#film').height(window.innerHeight * 1.3);

    // Converts a screen Y position to SVG units which have a viewBox transform
    var originTrans = null;
    function getTranslate(val) {
        if (!originTrans) {
            let matrix = document.querySelector('.legendGroup').transform.baseVal.getItem(0).matrix;
            originTrans = [matrix.e, matrix.f];
        };

        const svg = document.querySelector("#film>svg");
        let pt = svg.createSVGPoint();
        pt.x = 0;
        pt.y = val;
        pt = pt.matrixTransform(svg.getCTM().inverse());

        // console.debug(svg.getBBox().height);

        return [originTrans[0], pt.y + originTrans[1]];
    };


    window.addEventListener("scroll", function (evt) {
        let translate = getTranslate(window.scrollY);
        document.querySelector('.legendGroup')
            .setAttribute("transform", `translate(${translate[0]},${translate[1]})`);

        // console.debug(translate);
    });


});




    // (new Runtime).module(define, name => {
    //     if (name === "viewof keyframe") {
    //         window.alert("AA");
    //         // return new Inspector(document.querySelector(name));
    //         return Inspector.into("#aaa")();
    //     }
    // });

     // new Runtime().module(define, name => {
    //     if (name === "date")
    //         return {
    //             pending() { console.log(`${name} is running…`); },
    //             // fulfilled(value) { console.log(name, value); },
    //             rejected(error) { console.error(error); }
    //         };
    // });

    // document.querySelector("#chart").appendChild(value);
    // window.alert($("#replay"));